<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
  $(function() {
    $( "#dialog1" ).dialog();
  });
</script>
<style type="text/css">

.hide{
	display:none;
}
.show{
	display:block;
}

</style>
<script type="text/javascript" language="javascript">
function func1()
{
window.setTimeout(move, 100);
window.setTimeout(func2, 10200);
window.setTimeout(func3, 10200);
document.getElementById("loading").className="show";
document.getElementById("error").className="hide";
}
function func2()
{
	document.getElementById("loading").className="hide";
}
function func3()
{
	document.getElementById("error").className="show";
}
</script>
<style>
#myProgress {
  position: relative;
  width: 100%;
  height: 25px;
  background-color: #ddd;
}

#myBar {
  position: absolute;
  width: 0%;
  height: 25px;
  background-color: #4CAF50;
}

#label {
  text-align: center;
  line-height: 25px;
  color: black;
}
</style>
</head>
<body>
<div id="dialog1" title="ERROR">
<div id="error">
<p><img src="msgc.png" width="64" heght="64" /> ACCESS DENIED!</p>
<input type="button" value="Retry" style="float: right;" onclick="func1()" />
</div>
<div id="loading" class ="hide">
<p>Loading...<span id="label">0%</span></p>
<div id="myProgress">
  <div id="myBar">
  </div>
</div>
<script>
function move() {
  var elem = document.getElementById("myBar");   
  var width = 0;
  var id = setInterval(frame, 100);
  function frame() {
    if (width >= 100) {
      clearInterval(id);
    } else {
      width++; 
      elem.style.width = width + '%'; 
      document.getElementById("label").innerHTML = width * 1  + '%';
    }
  }
}
</script>
<br />
<input type="button" value="Retry" style="float: right;" disabled="disabled" />
</div>
</div>

</body>
</html>