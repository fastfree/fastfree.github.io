var jsuix_hasExceptions=false;function jsuix_errhandler(errstr,filename,lineno){return false;}
onError=jsuix_errhandler;function jsuix_evalExceptions(){jsuix_hasExceptions=eval('try {true} catch(e) {}');}
setTimeout('jsuix_evalExceptions()',1);