<html>
	<head>
		<title> The Use-full Web </title>

		<!-- META -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- CSS -->
		<link href="https://fastfree.cf/scripts/randomsite/css/style.css" rel="stylesheet" type="text/css">
		<link href='https://fonts.googleapis.com/css?family=Josefin+Slab' rel='stylesheet' type='text/css'>

		<!-- JS -->
		<script type="text/javascript" src="https://fastfree.cf/scripts/randomsite/js/uselessweb.js?v=1"></script>
		<script type="text/javascript" src="https://fastfree.cf/scripts/randomsite/js/libs/swfobject.js"></script>
		<script type="text/javascript" src="https://fastfree.cf/scripts/randomsite/js/libs/utils.js"></script>

	</head>
	<body>
<center>

		<hgroup>
			<h1> TAKE ME </h1>
			<h2 id='joint'> TO A </h2>
			<h3> USE-FULL </h3>
			<h4> WEBSITE </h4>
			<h5>&rarr;<button id='button'>PLEASE</button>&larr;</h5>
			<script>
				var uselessWebButton = new uselessWebButton( document.getElementById( 'button' ) ); 
			</script>
		</hgroup>

</center>
<a href="https://www.cloudrino.net/?ref=102383" style="color:red;">Free Cloud Server</a>
	</body>
</html>